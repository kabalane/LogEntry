﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogSort
{
    using System.Collections.Generic;


    class LogEntry : IComparable<LogEntry>
    {
        public String identifier { get; set; }
        public string line { get; set; }
        public Boolean isNumberString()
        {
            string s = line.Replace(" ", String.Empty);
            return s.All(char.IsDigit);
        }
        public int CompareTo(LogEntry other)
        {

            if (isNumberString()) return 1;
            // Alphabetic sort  [A to Z]
            if (this.line.CompareTo(other.line)==0)
            {
                return this.identifier.CompareTo(other.identifier);
            }
            //  sort. 
            return this.line.CompareTo(other.line);
        }

        public override string ToString()
        {
            // String representation.
            return this.identifier + " " + this.line;
        }

    }
}
